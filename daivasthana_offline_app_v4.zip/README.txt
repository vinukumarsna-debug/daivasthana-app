ದೈವಸ್ಥಾನ Offline App - Version 4

ಹೊಸ ವೈಶಿಷ್ಟ್ಯಗಳು:
1. 100 ಸದಸ್ಯರು
2. category-wise opening balance
3. category-wise payment allocation ಮತ್ತು automatic balance reduction
4. Sankramana ledger
5. Attendance
6. Member complete statement: current balance, payment history, attendance
7. Monthly payment report
8. Daily income/expense calculation
9. Improved receipt print layout for A4 / thermal
10. JSON backup/restore
11. Offline localStorage

ಗಮನಿಸಿ: ಇದು browser-based offline prototype; native APK ಅಲ್ಲ.
